


int converstionMilesToKM (){

double miles;

cout << "Please Enter A Number To Convert To KM" ;
cin >>  miles ;
cout << endl;
cout << "There are " ;

cout <<  miles / 1.609344;
cout << " KM ";
 
return 0;
}





